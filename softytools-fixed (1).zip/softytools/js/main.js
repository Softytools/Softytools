/* SOFTYTOOLS — shared site behaviour (theme, nav, forms) */
(function () {
  "use strict";

  /* ---------- Theme toggle ---------- */
  var root = document.documentElement;
  var stored = null;
  try { stored = localStorage.getItem("softytools-theme"); } catch (e) { /* storage unavailable */ }
  if (stored === "light" || stored === "dark") {
    root.setAttribute("data-theme", stored);
  }

  function currentTheme() {
    var attr = root.getAttribute("data-theme");
    if (attr) return attr;
    return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }

  function setTheme(theme) {
    root.setAttribute("data-theme", theme);
    try { localStorage.setItem("softytools-theme", theme); } catch (e) { /* ignore */ }
    var toggles = document.querySelectorAll(".theme-toggle");
    toggles.forEach(function (btn) {
      btn.setAttribute("aria-pressed", theme === "dark" ? "true" : "false");
      btn.setAttribute("aria-label", theme === "dark" ? "Switch to light mode" : "Switch to dark mode");
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    setTheme(currentTheme());
    document.querySelectorAll(".theme-toggle").forEach(function (btn) {
      btn.addEventListener("click", function () {
        setTheme(currentTheme() === "dark" ? "light" : "dark");
      });
    });

    /* ---------- Mobile nav ---------- */
    var navToggle = document.querySelector(".nav-toggle");
    var navLinks = document.querySelector(".nav-links");
    if (navToggle && navLinks) {
      navToggle.addEventListener("click", function () {
        var open = navLinks.classList.toggle("open");
        navToggle.setAttribute("aria-expanded", open ? "true" : "false");
      });
      navLinks.querySelectorAll("a").forEach(function (a) {
        a.addEventListener("click", function () {
          navLinks.classList.remove("open");
          navToggle.setAttribute("aria-expanded", "false");
        });
      });
    }

    /* ---------- Footer year ---------- */
    document.querySelectorAll("[data-year]").forEach(function (el) {
      el.textContent = new Date().getFullYear();
    });

    /* ---------- Forms: Contact & Request a Tool ---------- */
    document.querySelectorAll("form[data-softy-form]").forEach(initForm);
  });

  /**
   * Handles honest, working form submission.
   * Primary path: POST to a Formspree-compatible endpoint (set via data-endpoint).
   * Until a real endpoint is configured, the form clearly tells the user so
   * and offers a genuine mailto: fallback — never a fake "success" message.
   */
  function initForm(form) {
    var status = form.querySelector(".form-status");
    var endpoint = form.getAttribute("data-endpoint") || "";
    var isConfigured = endpoint && endpoint.indexOf("YOUR_FORM_ID") === -1 && endpoint.indexOf("your-form-id") === -1;
    var mailTo = form.getAttribute("data-mailto") || "hello@softytools.com";

    form.addEventListener("submit", function (evt) {
      evt.preventDefault();
      var formData = new FormData(form);

      if (!isConfigured) {
        showStatus(
          status,
          "info",
          "This form is not yet connected to a live backend. To send this now, use the mailto link below, " +
          "or the site owner can connect a real form endpoint (see README) to enable automatic admin notification."
        );
        offerMailtoFallback(form, formData, mailTo);
        return;
      }

      var submitBtn = form.querySelector('button[type="submit"]');
      if (submitBtn) submitBtn.disabled = true;
      showStatus(status, "info", "Sending your message…");

      fetch(endpoint, {
        method: "POST",
        headers: { Accept: "application/json" },
        body: formData
      })
        .then(function (res) {
          if (res.ok) {
            form.reset();
            showStatus(status, "success", "Thank you — your message was sent successfully. We reply within 2–3 business days.");
          } else {
            showStatus(status, "info", "We could not reach the server. Please try again, or email us directly at " + mailTo + ".");
          }
        })
        .catch(function () {
          showStatus(status, "info", "We could not reach the server. Please try again, or email us directly at " + mailTo + ".");
        })
        .finally(function () {
          if (submitBtn) submitBtn.disabled = false;
        });
    });
  }

  function showStatus(el, kind, msg) {
    if (!el) return;
    el.className = "form-status show " + kind;
    el.textContent = msg;
    el.setAttribute("role", "status");
  }

  function offerMailtoFallback(form, formData, mailTo) {
    var lines = [];
    formData.forEach(function (value, key) {
      lines.push(key + ": " + value);
    });
    var body = encodeURIComponent(lines.join("\n"));
    var subject = encodeURIComponent(form.getAttribute("data-subject") || "SOFTYTOOLS website message");
    var link = form.querySelector(".mailto-fallback");
    if (link) {
      link.href = "mailto:" + mailTo + "?subject=" + subject + "&body=" + body;
      link.hidden = false;
      link.focus();
    }
  }
})();
