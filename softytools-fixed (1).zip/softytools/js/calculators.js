/* SOFTYTOOLS — Calculator engine. All math runs client-side, live, no backend. */
(function () {
  "use strict";

  /* ---------------- Currency (persisted) ---------------- */
  var CURRENCIES = {
    USD: { symbol: "$", locale: "en-US" },
    GBP: { symbol: "£", locale: "en-GB" },
    EUR: { symbol: "€", locale: "de-DE" },
    CAD: { symbol: "CA$", locale: "en-CA" },
    AUD: { symbol: "A$", locale: "en-AU" }
  };
  var currencyCode = "USD";
  try { currencyCode = localStorage.getItem("softytools-currency") || "USD"; } catch (e) {}

  function fmtCurrency(value) {
    if (!isFinite(value)) return "—";
    var c = CURRENCIES[currencyCode] || CURRENCIES.USD;
    try {
      return new Intl.NumberFormat(c.locale, { style: "currency", currency: currencyCode, maximumFractionDigits: 2 }).format(value);
    } catch (e) {
      return c.symbol + value.toFixed(2);
    }
  }
  function fmtNumber(value, decimals) {
    if (!isFinite(value)) return "—";
    var d = decimals === undefined ? 2 : decimals;
    return new Intl.NumberFormat("en-US", { maximumFractionDigits: d, minimumFractionDigits: 0 }).format(value);
  }
  function fmtPercent(value, decimals) {
    if (!isFinite(value)) return "—";
    var d = decimals === undefined ? 2 : decimals;
    return fmtNumber(value, d) + "%";
  }

  function num(id) {
    var el = document.getElementById(id);
    if (!el) return NaN;
    var v = parseFloat(el.value);
    return isNaN(v) ? NaN : v;
  }
  function rawValue(id) {
    var el = document.getElementById(id);
    return el ? String(el.value).trim() : "";
  }
  function setText(id, text) {
    var el = document.getElementById(id);
    if (el) el.textContent = text;
  }
  function setWarn(id, text) {
    var el = document.getElementById(id);
    if (!el) return;
    if (text) {
      el.textContent = text;
      el.style.display = "flex";
    } else {
      el.style.display = "none";
    }
  }
  function on(ids, evt, fn) {
    ids.forEach(function (id) {
      var el = document.getElementById(id);
      if (el) el.addEventListener(evt, fn);
    });
  }

  /**
   * Validates a single numeric input field.
   * Returns null when the value is valid, or a plain-language error
   * message string when it is empty, non-numeric, or out of the
   * allowed range. Never lets NaN/Infinity reach a calculation.
   *
   * options:
   *   label          - human-readable field name used in the message
   *   required       - defaults to true; set false for optional fields
   *   allowZero      - defaults to false
   *   allowNegative  - defaults to false
   *   min / max      - optional numeric bounds (inclusive)
   */
  function validateNumber(id, options) {
    options = options || {};
    var el = document.getElementById(id);
    if (!el) return null; // field not present on this page
    var label = options.label || "This field";
    var raw = String(el.value).trim();

    if (raw === "") {
      return options.required === false ? null : (label + " is required.");
    }

    var value = Number(raw);
    if (isNaN(value) || !isFinite(value)) {
      return label + " must be a valid number.";
    }
    if (!options.allowNegative && value < 0) {
      return label + " can't be negative.";
    }
    if (!options.allowZero && value === 0) {
      return label + " can't be zero.";
    }
    if (options.min !== undefined && value < options.min) {
      return label + " must be at least " + options.min + ".";
    }
    if (options.max !== undefined && value > options.max) {
      return label + " can't be more than " + options.max + ".";
    }
    return null;
  }

  /** Runs a list of validateNumber() calls and returns only the failures. */
  function collectErrors(checks) {
    var errors = [];
    for (var i = 0; i < checks.length; i++) {
      if (checks[i]) errors.push(checks[i]);
    }
    return errors;
  }

  /* ================================================================
     1) POSITION SIZE CALCULATOR
     Risk Amount = Balance x (Risk% / 100)
     Price Risk per unit = |Entry - Stop|
     Position Size (units) = Risk Amount / Price Risk per unit
     ================================================================ */
  function calcPositionSize() {
    setWarn("ps-warn", "");
    var errors = collectErrors([
      validateNumber("ps-balance", { label: "Account balance" }),
      validateNumber("ps-risk-pct", { label: "Risk per trade (%)", max: 100 }),
      validateNumber("ps-entry", { label: "Entry price" }),
      validateNumber("ps-stop", { label: "Stop-loss price" }),
      validateNumber("ps-contract-size", { label: "Units per lot", required: false })
    ]);
    if (errors.length) {
      setWarn("ps-warn", errors[0]);
      setText("ps-units", "—"); setText("ps-lots", "—"); setText("ps-risk-amount", "—"); setText("ps-value", "—");
      return;
    }

    var balance = num("ps-balance");
    var riskPct = num("ps-risk-pct");
    var entry = num("ps-entry");
    var stop = num("ps-stop");
    var contractSize = rawValue("ps-contract-size") === "" ? 1 : num("ps-contract-size");

    if (entry === stop) {
      setWarn("ps-warn", "Entry price and stop-loss price can't be equal — there is no price risk to measure.");
      setText("ps-units", "—"); setText("ps-lots", "—");
      setText("ps-risk-amount", fmtCurrency(balance * (riskPct / 100))); setText("ps-value", "—");
      return;
    }

    var priceRisk = Math.abs(entry - stop);
    var riskAmount = balance * (riskPct / 100);
    var units = riskAmount / priceRisk;
    var lots = units / contractSize;
    var positionValue = units * entry;

    if (riskPct > 5) {
      setWarn("ps-warn", "A risk of over 5% per trade is considered high risk by most risk-management frameworks.");
    }
    setText("ps-units", fmtNumber(units, 4));
    setText("ps-lots", fmtNumber(lots, 4));
    setText("ps-risk-amount", fmtCurrency(riskAmount));
    setText("ps-value", fmtCurrency(positionValue));
  }

  /* ================================================================
     2) TRADING RISK % CALCULATOR
     Risk Amount = |Entry - Stop| x Position Size
     Risk % = Risk Amount / Balance x 100
     ================================================================ */
  function calcRiskPercent() {
    setWarn("rp-warn", "");
    var errors = collectErrors([
      validateNumber("rp-balance", { label: "Account balance" }),
      validateNumber("rp-entry", { label: "Entry price" }),
      validateNumber("rp-stop", { label: "Stop-loss price" }),
      validateNumber("rp-size", { label: "Position size" })
    ]);
    if (errors.length) {
      setWarn("rp-warn", errors[0]);
      setText("rp-amount", "—"); setText("rp-pct", "—");
      return;
    }

    var balance = num("rp-balance");
    var entry = num("rp-entry");
    var stop = num("rp-stop");
    var size = num("rp-size");

    var priceRisk = Math.abs(entry - stop);
    var riskAmount = priceRisk * size;
    var riskPct = (riskAmount / balance) * 100;

    setText("rp-amount", fmtCurrency(riskAmount));
    setText("rp-pct", fmtPercent(riskPct));
    if (entry === stop) {
      setWarn("rp-warn", "Entry and stop-loss are equal, so this trade currently has no price risk.");
    } else if (riskPct > 5) {
      setWarn("rp-warn", "This trade risks more than 5% of your account — well above what most risk models recommend.");
    }
  }

  /* ================================================================
     3) RISK / REWARD CALCULATOR
     Risk = |Entry - Stop|   Reward = |Target - Entry|
     RR = Reward / Risk      Breakeven win rate = Risk / (Risk + Reward)
     ================================================================ */
  function calcRiskReward() {
    setWarn("rr-warn", "");
    var errors = collectErrors([
      validateNumber("rr-entry", { label: "Entry price" }),
      validateNumber("rr-stop", { label: "Stop-loss price" }),
      validateNumber("rr-target", { label: "Take-profit price" })
    ]);
    if (errors.length) {
      setWarn("rr-warn", errors[0]);
      setText("rr-ratio", "—"); setText("rr-risk", "—"); setText("rr-reward", "—"); setText("rr-breakeven", "—");
      return;
    }

    var entry = num("rr-entry");
    var stop = num("rr-stop");
    var target = num("rr-target");

    if (entry === stop) {
      setWarn("rr-warn", "Entry price and stop-loss price can't be equal — the risk distance would be zero.");
      setText("rr-ratio", "—"); setText("rr-risk", "—"); setText("rr-reward", "—"); setText("rr-breakeven", "—");
      return;
    }

    var risk = Math.abs(entry - stop);
    var reward = Math.abs(target - entry);
    var ratio = reward / risk;
    var breakeven = (risk / (risk + reward)) * 100;

    setText("rr-ratio", "1 : " + fmtNumber(ratio, 2));
    setText("rr-risk", fmtNumber(risk, 5));
    setText("rr-reward", fmtNumber(reward, 5));
    setText("rr-breakeven", fmtPercent(breakeven));
    if (ratio < 1) setWarn("rr-warn", "This setup risks more than it targets (ratio below 1:1) — it needs a high win rate to stay profitable.");
  }

  /* ================================================================
     4) STOP LOSS CALCULATOR
     Distance = Risk Amount / Position Size
     Long:  Stop = Entry - Distance     Short: Stop = Entry + Distance
     ================================================================ */
  function calcStopLoss() {
    setWarn("sl-warn", "");
    var errors = collectErrors([
      validateNumber("sl-balance", { label: "Account balance" }),
      validateNumber("sl-risk-pct", { label: "Risk per trade (%)", max: 100 }),
      validateNumber("sl-entry", { label: "Entry price" }),
      validateNumber("sl-size", { label: "Position size" })
    ]);
    if (errors.length) {
      setWarn("sl-warn", errors[0]);
      setText("sl-price", "—"); setText("sl-distance", "—"); setText("sl-amount", "—");
      return;
    }

    var balance = num("sl-balance");
    var riskPct = num("sl-risk-pct");
    var entry = num("sl-entry");
    var size = num("sl-size");
    var direction = (document.querySelector('input[name="sl-direction"]:checked') || {}).value || "long";

    var riskAmount = balance * (riskPct / 100);
    var distance = riskAmount / size;
    var stopPrice = direction === "long" ? entry - distance : entry + distance;

    if (stopPrice <= 0) setWarn("sl-warn", "The calculated stop-loss price is at or below zero — reduce risk % or position size.");
    setText("sl-price", fmtNumber(stopPrice, 5));
    setText("sl-distance", fmtNumber(distance, 5));
    setText("sl-amount", fmtCurrency(riskAmount));
  }

  /* ================================================================
     5) TAKE PROFIT CALCULATOR
     Risk Distance = |Entry - Stop|
     Long:  TP = Entry + (RR x Risk Distance)
     Short: TP = Entry - (RR x Risk Distance)
     ================================================================ */
  function calcTakeProfit() {
    setWarn("tp-warn", "");
    var errors = collectErrors([
      validateNumber("tp-entry", { label: "Entry price" }),
      validateNumber("tp-stop", { label: "Stop-loss price" }),
      validateNumber("tp-rr", { label: "Target risk/reward ratio" })
    ]);
    if (errors.length) {
      setWarn("tp-warn", errors[0]);
      setText("tp-price", "—"); setText("tp-distance", "—");
      return;
    }

    var entry = num("tp-entry");
    var stop = num("tp-stop");
    var rr = num("tp-rr");
    var direction = (document.querySelector('input[name="tp-direction"]:checked') || {}).value || "long";

    if (entry === stop) {
      setWarn("tp-warn", "Entry price and stop-loss price can't be equal — the risk distance would be zero.");
      setText("tp-price", "—"); setText("tp-distance", "—");
      return;
    }

    var riskDistance = Math.abs(entry - stop);
    var rewardDistance = riskDistance * rr;
    var tpPrice = direction === "long" ? entry + rewardDistance : entry - rewardDistance;

    setText("tp-price", fmtNumber(tpPrice, 5));
    setText("tp-distance", fmtNumber(rewardDistance, 5));
    if (tpPrice <= 0) setWarn("tp-warn", "The calculated take-profit price is at or below zero — check your entry, stop and ratio inputs.");
  }

  /* ================================================================
     6) LEVERAGE CALCULATOR
     Leverage = Position Value / Margin (Equity used)
     Margin Required = Position Value / Leverage
     Max Position Value = Equity x Leverage
     ================================================================ */
  function calcLeverage() {
    setWarn("lv-warn", "");
    var modeEl = document.querySelector('input[name="lv-mode"]:checked');
    var mode = modeEl ? modeEl.value : "find-leverage";

    var checks = [
      validateNumber("lv-equity", { label: "Account equity" }),
      validateNumber("lv-position", { label: "Position value" })
    ];
    if (mode === "find-margin") {
      checks.push(validateNumber("lv-leverage", { label: "Leverage" }));
    }
    var errors = collectErrors(checks);
    if (errors.length) {
      setWarn("lv-warn", errors[0]);
      setText("lv-out-leverage", "—"); setText("lv-out-margin", "—"); setText("lv-out-maxpos", "—");
      return;
    }

    var equity = num("lv-equity");
    var positionValue = num("lv-position");

    if (mode === "find-leverage") {
      var lev = positionValue / equity;
      setText("lv-out-leverage", fmtNumber(lev, 2) + "x");
      setText("lv-out-margin", "—");
      setText("lv-out-maxpos", "—");
      if (lev > 50) setWarn("lv-warn", "Leverage above 50x carries a very high liquidation risk from small price moves.");
    } else {
      var leverage = num("lv-leverage");
      var margin = positionValue / leverage;
      var maxPos = equity * leverage;
      setText("lv-out-margin", fmtCurrency(margin));
      setText("lv-out-maxpos", fmtCurrency(maxPos));
      setText("lv-out-leverage", fmtNumber(leverage, 2) + "x");
      if (margin > equity) setWarn("lv-warn", "Required margin exceeds your account equity — this position can't be opened at this leverage.");
      else if (leverage > 50) setWarn("lv-warn", "Leverage above 50x carries a very high liquidation risk from small price moves.");
    }
  }

  /* ================================================================
     7) DRAWDOWN CALCULATOR
     Drawdown % = (Peak - Trough) / Peak x 100
     Recovery Needed % = (Peak - Trough) / Trough x 100
     ================================================================ */
  function calcDrawdown() {
    setWarn("dd-warn", "");
    var errors = collectErrors([
      validateNumber("dd-peak", { label: "Peak balance" }),
      validateNumber("dd-trough", { label: "Current balance", allowZero: true })
    ]);
    if (errors.length) {
      setWarn("dd-warn", errors[0]);
      setText("dd-pct", "—"); setText("dd-loss", "—"); setText("dd-recovery", "—");
      return;
    }

    var peak = num("dd-peak");
    var trough = num("dd-trough");

    if (trough > peak) {
      setWarn("dd-warn", "Your current balance is above the peak — there is no drawdown right now.");
      setText("dd-pct", "0.00%"); setText("dd-loss", fmtCurrency(0)); setText("dd-recovery", "0.00%");
      return;
    }
    if (trough === 0) {
      setWarn("dd-warn", "Current balance is zero — the account is fully drawn down, and no gain percentage can recover it mathematically.");
      setText("dd-pct", "100.00%"); setText("dd-loss", fmtCurrency(peak)); setText("dd-recovery", "—");
      return;
    }

    var loss = peak - trough;
    var ddPct = (loss / peak) * 100;
    var recoveryPct = (loss / trough) * 100;

    setText("dd-pct", fmtPercent(ddPct));
    setText("dd-loss", fmtCurrency(loss));
    setText("dd-recovery", fmtPercent(recoveryPct));
    if (ddPct > 20) setWarn("dd-warn", "A drawdown over 20% requires a large percentage gain just to recover — review position sizing and risk per trade.");
  }

  /* ================================================================
     8) ROI CALCULATOR
     ROI % = (Final - Initial) / Initial x 100
     Annualized ROI % = ((Final/Initial)^(365/days) - 1) x 100
     ================================================================ */
  function calcROI() {
    setWarn("roi-warn", "");
    var errors = collectErrors([
      validateNumber("roi-initial", { label: "Initial investment" }),
      validateNumber("roi-final", { label: "Final value", allowZero: true })
    ]);
    if (errors.length) {
      setWarn("roi-warn", errors[0]);
      setText("roi-profit", "—"); setText("roi-pct", "—"); setText("roi-annual", "—");
      return;
    }

    var initial = num("roi-initial");
    var final = num("roi-final");
    var netProfit = final - initial;
    var roiPct = (netProfit / initial) * 100;

    setText("roi-profit", fmtCurrency(netProfit));
    setText("roi-pct", fmtPercent(roiPct));

    var daysRaw = rawValue("roi-days");
    if (daysRaw === "") {
      setText("roi-annual", "Add a holding period to see this");
      return;
    }
    var daysError = validateNumber("roi-days", { label: "Holding period (days)", required: false });
    if (daysError) {
      setText("roi-annual", "—");
      setWarn("roi-warn", daysError);
      return;
    }

    var days = num("roi-days");
    var annualized = (Math.pow(final / initial, 365 / days) - 1) * 100;
    setText("roi-annual", fmtPercent(annualized));
  }

  /* ================================================================
     9) COMPOUND INVESTMENT CALCULATOR
     FV = P(1+r/n)^(nt) + PMT * (((1+r/n)^(nt) - 1) / (r/n))
     ================================================================ */
  function calcCompound() {
    setWarn("ci-warn", "");
    var errors = collectErrors([
      validateNumber("ci-principal", { label: "Starting amount", allowZero: true }),
      validateNumber("ci-contribution", { label: "Contribution per period", allowZero: true }),
      validateNumber("ci-rate", { label: "Annual interest rate (%)", allowZero: true, max: 1000 }),
      validateNumber("ci-years", { label: "Years", allowZero: true, max: 100 })
    ]);
    if (errors.length) {
      setWarn("ci-warn", errors[0]);
      setText("ci-final", "—"); setText("ci-contributed", "—"); setText("ci-interest", "—");
      return;
    }

    var principal = num("ci-principal");
    var contribution = num("ci-contribution");
    var rate = num("ci-rate");
    var years = num("ci-years");
    var freqSel = document.getElementById("ci-frequency");
    var n = freqSel ? parseFloat(freqSel.value) : 12;

    var r = rate / 100;
    var periods = n * years;
    var ratePerPeriod = r / n;

    var fvPrincipal = principal * Math.pow(1 + ratePerPeriod, periods);
    var fvContrib = ratePerPeriod > 0
      ? contribution * ((Math.pow(1 + ratePerPeriod, periods) - 1) / ratePerPeriod)
      : contribution * periods;

    var final = fvPrincipal + fvContrib;
    var totalContributed = principal + (contribution * periods);
    var interestEarned = final - totalContributed;

    setText("ci-final", fmtCurrency(final));
    setText("ci-contributed", fmtCurrency(totalContributed));
    setText("ci-interest", fmtCurrency(interestEarned));
    if (rate > 30) setWarn("ci-warn", "A sustained annual return above 30% is extremely rare — double-check this assumption.");
  }

  /* ================================================================
     Tab switching
     ================================================================ */
  function initTabs() {
    var buttons = Array.prototype.slice.call(document.querySelectorAll(".calc-nav [role='tab']"));
    var panels = document.querySelectorAll(".calc-panel");
    if (!buttons.length) return;

    function activate(id, pushHash, focusTab) {
      buttons.forEach(function (b) {
        var selected = b.getAttribute("data-target") === id;
        b.setAttribute("aria-selected", selected ? "true" : "false");
        b.setAttribute("tabindex", selected ? "0" : "-1");
      });
      panels.forEach(function (p) {
        p.classList.toggle("active", p.id === id);
      });
      if (pushHash) history.replaceState(null, "", "#" + id);
      if (focusTab) {
        var btn = buttons.filter(function (b) { return b.getAttribute("data-target") === id; })[0];
        if (btn) btn.focus();
      }
    }

    buttons.forEach(function (b, index) {
      b.addEventListener("click", function () { activate(b.getAttribute("data-target"), true, false); });

      b.addEventListener("keydown", function (evt) {
        var targetIndex = null;
        switch (evt.key) {
          case "ArrowRight":
          case "ArrowDown":
            targetIndex = (index + 1) % buttons.length;
            break;
          case "ArrowLeft":
          case "ArrowUp":
            targetIndex = (index - 1 + buttons.length) % buttons.length;
            break;
          case "Home":
            targetIndex = 0;
            break;
          case "End":
            targetIndex = buttons.length - 1;
            break;
          default:
            return;
        }
        evt.preventDefault();
        activate(buttons[targetIndex].getAttribute("data-target"), true, true);
      });
    });

    var initial = (location.hash || "").replace("#", "");
    var validIds = Array.prototype.map.call(panels, function (p) { return p.id; });
    if (!validIds.includes(initial)) initial = validIds[0];
    activate(initial, false, false);
  }

  /* ---------------- Currency selector ---------------- */
  function initCurrency() {
    var sel = document.getElementById("currencySelect");
    if (!sel) return;
    sel.value = currencyCode;
    sel.addEventListener("change", function () {
      currencyCode = sel.value;
      try { localStorage.setItem("softytools-currency", currencyCode); } catch (e) {}
      recalcAll();
    });
  }

  function recalcAll() {
    [calcPositionSize, calcRiskPercent, calcRiskReward, calcStopLoss, calcTakeProfit,
      calcLeverage, calcDrawdown, calcROI, calcCompound].forEach(function (fn) {
      try { fn(); } catch (e) { /* panel not on this page */ }
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    if (!document.body.classList.contains("calculator-page")) return;

    initTabs();
    initCurrency();

    on(["ps-balance", "ps-risk-pct", "ps-entry", "ps-stop", "ps-contract-size"], "input", calcPositionSize);
    on(["rp-balance", "rp-entry", "rp-stop", "rp-size"], "input", calcRiskPercent);
    on(["rr-entry", "rr-stop", "rr-target"], "input", calcRiskReward);
    on(["sl-balance", "sl-risk-pct", "sl-entry", "sl-size"], "input", calcStopLoss);
    document.querySelectorAll('input[name="sl-direction"]').forEach(function (r) { r.addEventListener("change", calcStopLoss); });
    on(["tp-entry", "tp-stop", "tp-rr"], "input", calcTakeProfit);
    document.querySelectorAll('input[name="tp-direction"]').forEach(function (r) { r.addEventListener("change", calcTakeProfit); });
    on(["lv-equity", "lv-leverage", "lv-position"], "input", calcLeverage);
    document.querySelectorAll('input[name="lv-mode"]').forEach(function (r) { r.addEventListener("change", calcLeverage); });
    on(["dd-peak", "dd-trough"], "input", calcDrawdown);
    on(["roi-initial", "roi-final", "roi-days"], "input", calcROI);
    on(["ci-principal", "ci-contribution", "ci-rate", "ci-years"], "input", calcCompound);
    var ciFreq = document.getElementById("ci-frequency");
    if (ciFreq) ciFreq.addEventListener("change", calcCompound);

    recalcAll();
  });

  /* Expose for the homepage mini-calculator */
  window.SoftyCalc = { fmtCurrency: fmtCurrency, fmtNumber: fmtNumber, fmtPercent: fmtPercent };
})();
