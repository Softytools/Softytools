# SOFTYTOOLS

**Fast. Smart. Trade Better.**

A free, worldwide trading & investment calculator website. Nine genuinely
working, client-side calculators (Position Size, Trading Risk %, Risk/Reward,
Stop Loss, Take Profit, Leverage, Drawdown, ROI, Compound Investment), plus
original guides, a light/dark theme, and clean technical SEO.

This is a **static site** — plain HTML, CSS and vanilla JavaScript. No build
step, no framework, no server required. Every calculation runs entirely in
the visitor's browser.

## Project structure

```
/index.html                 Home
/calculator.html            All 9 calculators (tabbed)
/guides.html                Guides index
/guides/*.html              4 in-depth guides
/about.html
/contact.html                Contact form
/request-a-tool.html         Tool request form
/privacy-policy.html
/terms.html
/disclaimer.html
/404.html
/robots.txt
/sitemap.xml
/_headers                    Cloudflare Pages response headers
/_redirects                  Cloudflare Pages 404 routing
/css/style.css               Design tokens + all site styles
/js/main.js                  Theme toggle, mobile nav, form handling
/js/calculators.js           All 9 calculator engines + tab switching
/assets/mark.svg             Flame logo mark (header/footer)
/assets/favicon.svg          Favicon
/assets/og-image.png         Social share image
```

## Deploying to Cloudflare Pages

1. Push this folder to a GitHub repository.
2. In the Cloudflare dashboard: **Workers & Pages → Create → Pages → Connect
   to Git**, select the repository.
3. Build settings: **no build command**, output directory = `/` (project
   root). This is a static site, so leave the framework preset as "None".
4. Deploy. Cloudflare Pages will serve the site directly, including
   `_headers` and `_redirects`.
5. Before going live, update every occurrence of
   `https://www.softytools.com` in the HTML files (canonical tags, Open
   Graph URLs, JSON-LD, `robots.txt`, `sitemap.xml`) to your real domain.

## Connecting the Contact and Request a Tool forms — required step

Both forms are **fully wired up in the front end** but need a real backend
endpoint to deliver submissions, because this project ships no server. Until
you configure one, submitting a form will **not** show a fake "success"
message — it will clearly tell the visitor the form isn't connected yet and
offer a genuine `mailto:` link as a working fallback. This is intentional:
the site never simulates a backend it doesn't have.

To enable full submission + admin email notification:

1. Create a free form endpoint at [Formspree](https://formspree.io) (or any
   compatible service — Getform, Basin, etc. work the same way).
2. In `contact.html` and `request-a-tool.html`, find the `<form>` tag and
   replace:
   ```html
   data-endpoint="https://formspree.io/f/YOUR_FORM_ID"
   ```
   with your real endpoint URL.
3. Also update `data-mailto="hello@softytools.com"` (and
   `requests@softytools.com`) to your real support email addresses — these
   are used both as the fallback `mailto:` target and in on-page copy.
4. Redeploy. `js/main.js` will detect the real endpoint automatically and
   switch from "fallback mode" to live submission with a genuine success/
   error status message.

No other code changes are required — the detection logic lives entirely in
`initForm()` inside `js/main.js`.

## Currency & theme persistence

The Calculator page's currency selector and the site-wide light/dark toggle
are stored in the visitor's own `localStorage` only. No data is sent to a
server. If `localStorage` is unavailable (e.g. private browsing), both
features degrade gracefully to their defaults (USD, system theme).

## AdSense readiness

- Content is 100% original, with real formulas and no fabricated statistics
  or reviews.
- Clear navigation, Privacy Policy, Terms of Use and Financial Disclaimer
  are all in place.
- `.ad-slot` placeholders are clearly labeled, sit outside calculator forms,
  and are never intrusive by design — swap them for your ad network's script
  when ready. This project does not guarantee AdSense approval or search
  rankings.

## SEO checklist already implemented

- Unique `<title>` and meta description per page
- One `<h1>` per page, semantic `<h2>`/`<h3>` structure
- Canonical URLs on every page
- `robots.txt` and `sitemap.xml`
- Breadcrumbs (visual + `BreadcrumbList` JSON-LD) on every inner page
- Open Graph + Twitter Card metadata
- `Organization`, `WebSite`, `SoftwareApplication` and `FAQPage` JSON-LD
  where relevant
- Descriptive `alt` text on meaningful images (decorative marks use `alt=""`)
- Internal linking between Home, Calculator, and each Guide

## SEO fix pass (September 15, 2026)

A targeted audit follow-up addressed five specific findings without touching
design, branding, calculators, formulas, or navigation:

1. **Meta description** — homepage description shortened from 172 to 141
   characters.
2. **Image alt text** — the two logo `<img>` elements (header + footer) now
   use `alt="SOFTYTOOLS logo"` site-wide, instead of an empty `alt=""`.
3. **Organization schema `sameAs`** — removed rather than populated with
   invented URLs, since SOFTYTOOLS has no genuine public social profiles yet.
   Add real profile URLs to the `Organization` JSON-LD in `index.html` once
   they exist — never fabricate them.
4. **Content freshness** — each of the 4 guides now shows a visible
   "Published / Updated" byline and carries `Article` JSON-LD with honest
   `datePublished` (2026-09-14, when the guide was first written) and
   `dateModified` (2026-09-15, this fix pass). Update `dateModified` whenever
   a guide's content actually changes — never backdate or leave it stale.
5. **Author information** — guides now credit "SOFTYTOOLS Editorial Team"
   with a short, honest bio, both visibly on the page and in each guide's
   `Article` JSON-LD `author` field. This is an intentional organizational
   byline, not a fabricated individual.

## Performance notes

- No JS framework or build step — two small vanilla JS files.
- Google Fonts are loaded with `preconnect` and `display=swap`.
- All icons are inline SVG (no icon-font request).
- Images are minimal; the only raster asset is the social share image.
